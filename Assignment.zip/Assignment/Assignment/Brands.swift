//
//  Brands.swift
//  Assignment
//
//  Created by Anji on 21/05/19.
//  Copyright © 2019 com.callistoinfosolutions.Task. All rights reserved.
//

import Foundation

struct Brands {
    
    var brandName:String?
    var price:String?
    var createdAt:String?
    var id:String?
    
    init(data:[String:Any]?) {
        brandName = data?[Constants.BRANDNAME] as? String
        price = data?[Constants.PRICE] as? String
        createdAt = data?[Constants.TIMESTAMP] as? String
        id  = data?[Constants.ID] as? String
    }
    
}
