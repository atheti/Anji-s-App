//
//  Constants.swift
//  Assignment
//
//  Created by Anji on 21/05/19.
//  Copyright © 2019 com.callistoinfosolutions.Task. All rights reserved.
//

import Foundation
import UIKit

struct Constants {
    
    static var CHILD:String{
        return "Brand"
    }
    static var ID:String{
        return "ID"
    }
    static var BRANDNAME:String{
        return "brand_name"
    }
    static var PRICE:String{
        return "price"
    }
    static var TIMESTAMP:String{
        return "timeStamp"
    }
}
