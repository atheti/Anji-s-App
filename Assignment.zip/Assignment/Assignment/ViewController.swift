//
//  ViewController.swift
//  Assignment
//
//  Created by Anji on 21/05/19.
//  Copyright © 2019 com.callistoinfosolutions.Task. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var brandNameTxtFiled: UITextField!
    @IBOutlet weak var priceTxtFiled: UITextField!
    @IBOutlet weak var brandColletionView: UICollectionView!
    
    private var brandListArr:[Brands] = []
    private var loadMore = true
    private var images = [#imageLiteral(resourceName: "apple1"), #imageLiteral(resourceName: "iphone_x"), #imageLiteral(resourceName: "apple3"), #imageLiteral(resourceName: "apple2"), #imageLiteral(resourceName: "image")]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        brandColletionView.transform = CGAffineTransform.init(rotationAngle: (-(CGFloat)(Double.pi)))
        priceTxtFiled.inputAccessoryView = addDoneButton()
        willFetchBrandsFromDatabase()
        
    }
    
    //MARK:- Action for
    @IBAction func didTappedOnAddBrand(_ sender: Any) {
        if (brandNameTxtFiled.text ?? "").isBlank{
            return
        }
        if (priceTxtFiled.text ?? "").isBlank {
            return
        }
        AppDatabase.shared.addBrand(brandName:brandNameTxtFiled.text ?? "", price:priceTxtFiled.text ?? "")
        view.endEditing(true)
    }
    
    fileprivate func willFetchBrandsFromDatabase(){
        showActivityIndicatory()
        loadMore = false
        AppDatabase.shared.willFetchBrands(lastPost: brandListArr.last) {[weak self] (brands) in
            self?.hideActivityIndicator()
            guard let cBrands = brands else {return}
            if cBrands.isEmpty{
                self?.loadMore = false
            }else{
                self?.loadMore = true
            }
            self?.brandListArr.append(contentsOf: cBrands)
            self?.brandColletionView.reloadData()
            self?.brandColletionView.scrollsToTop = true
        }
    }

}

extension ViewController:UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       return brandListArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let  cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BrandListCell", for: indexPath) as! BrandListCell
        cell.brand = brandListArr[indexPath.row]
        cell.brandImageView.image = images.randomElement()
        cell.transform = CGAffineTransform(rotationAngle: CGFloat.pi)
        return cell
    }

}

extension ViewController:UICollectionViewDelegate{
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if scrollView.isAtBottom {
            if loadMore{
                willFetchBrandsFromDatabase()
            }
        }
    }
    
}

extension ViewController:UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.bounds.size.width - 30) / 2, height: (collectionView.frame.height - 50) / 2)
    }
    
}

extension ViewController:UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
