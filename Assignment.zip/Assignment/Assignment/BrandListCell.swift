//
//  BrandListCell.swift
//  Assignment
//
//  Created by Anji on 21/05/19.
//  Copyright © 2019 com.callistoinfosolutions.Task. All rights reserved.
//

import UIKit

class BrandListCell: UICollectionViewCell {
    
    @IBOutlet weak var lblBrandName: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var brandImageView: UIImageView!
    
    let shadow = UIColor.black.withAlphaComponent(0.8).cgColor
    var brand:Brands?{
        didSet{
            lblBrandName.text = brand?.brandName
            lblPrice.text = brand?.price
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()

    }
    
}
