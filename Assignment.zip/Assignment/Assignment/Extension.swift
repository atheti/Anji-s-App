//
//  Extension.swift
//  Assignment
//
//  Created by Anji on 21/05/19.
//  Copyright © 2019 com.callistoinfosolutions.Task. All rights reserved.
//

import Foundation
import UIKit

extension String {
    
    var isBlank:Bool{
        return self.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    
}

extension UIViewController{
    
    func addDoneButton() -> UIToolbar{
        let keyboardToolbar = UIToolbar()
        keyboardToolbar.sizeToFit()
        let flexBarButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace,
                                            target: nil, action: nil)
        let doneBarButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(hideboard))
        keyboardToolbar.items = [flexBarButton, doneBarButton]
        
        return keyboardToolbar
    }
    
    @objc func hideboard(){
        view.endEditing(true)
    }
    
    func showActivityIndicatory() {
        let screenSize:CGRect = UIScreen.main.bounds
        let bgView = UIView(frame: CGRect(x: 0, y: 64, width: screenSize.width, height: screenSize.height - 64))
        bgView.tag = 1201
        
        bgView.backgroundColor = UIColor.clear
        let bgBounds = bgView.bounds
        let activityIndicator = UIActivityIndicatorView(frame: CGRect(x: Int(bgBounds.width / 2) - 18,
                                                                      y: Int(bgBounds.height / 2) - 18, width: 37, height: 37))
        activityIndicator.style = .whiteLarge
        activityIndicator.color = #colorLiteral(red: 0.05882352963, green: 0.180392161, blue: 0.2470588237, alpha: 1)
        bgView.addSubview(activityIndicator)
        self.view.addSubview(bgView)
        activityIndicator.isHidden = false
        activityIndicator.startAnimating()
    }
    
    func  hideActivityIndicator() {
        if let bgView = self.view.viewWithTag(1201) {
            bgView.removeFromSuperview()
        }
    }
    
}

extension Date {
    func timeStamp() -> Int64 {
        return Int64(self.timeIntervalSince1970 * 1000)
    }
}

extension UIScrollView {
    
    var isAtBottom: Bool {
        return contentOffset.y >= verticalOffsetForBottom
    }
    
    var verticalOffsetForBottom: CGFloat {
        let scrollViewHeight = bounds.height
        let scrollContentSizeHeight = contentSize.height
        let bottomInset = contentInset.bottom
        let scrollViewBottomOffset = scrollContentSizeHeight + bottomInset - scrollViewHeight
        return scrollViewBottomOffset
    }
    
}
