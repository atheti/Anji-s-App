//
//  AppDatabase.swift
//  Assignment
//
//  Created by Anji on 21/05/19.
//  Copyright © 2019 com.callistoinfosolutions.Task. All rights reserved.
//

import Foundation
import FirebaseDatabase

class AppDatabase {
    
    var databaseRef:DatabaseReference?{
        return Database.database().reference().child(Constants.CHILD)
    }
    
    static var shared:AppDatabase{
        return AppDatabase()
    }
    
    fileprivate var dbKey:String{
        let key = databaseRef?.childByAutoId().key
        return key ?? ""
    }
    
    private var queryRef:DatabaseQuery?
    private var startKey:String?
    private init(){}
    
    func addBrand(brandName:String, price:String){
        let brandDict:[String : Any] = [Constants.ID:dbKey, Constants.BRANDNAME:brandName, Constants.PRICE:price, Constants.TIMESTAMP:Date().timeStamp().description]
        databaseRef?.child(dbKey).setValue(brandDict)
    }
    
    func willFetchBrands(lastPost:Brands?, _ completion:@escaping(_ brands:[Brands]?) -> Swift.Void){
        startKey = lastPost?.id
        if startKey == nil {
            queryRef = databaseRef?.queryLimited(toFirst: 4)
        }else{
            queryRef = databaseRef?.queryOrderedByKey().queryStarting(atValue: startKey!).queryLimited(toFirst: 4)
        }
        queryRef?.observeSingleEvent(of: .value, with: { (snapShot) in
            var tempBrandArr = [Brands]()
            for child in snapShot.children{
                if let childrenSnapShot = child as? DataSnapshot {
                    let brandDict = childrenSnapShot.value as? [String:Any]
                    let brand = Brands(data: brandDict)
                    if brand.id != lastPost?.id{
                        tempBrandArr.append(brand)
                    }
                }
            }
            DispatchQueue.main.async {
                if lastPost?.createdAt != tempBrandArr.last?.createdAt{
                    completion(tempBrandArr)
                }else{
                    completion(nil)
                }
            }
        })
    }
    
}
